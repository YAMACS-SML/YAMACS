The files contained in this .zip file must be extracted inside YASARA installation folder, in the PLG directory, along with the plugins.py Python script files. The files are needed for the correct functioning of the plugins.

The .zip file contains the following files:
- this README_YAMACS.txt
- charmm36 folder, containing CHARMM36 force field, version mar2019
- nine background PNGs.


To ensure that everythin is installed correctly, check that the path of the files are the following:

- for Python scripts
	/home/.../yasara/plg/YAMACS_script_name.py
- for background PNG files
	/home/.../yasara/plg/BG_number.png
- for CHARM36 force field
	/home/.../yasara/plg/charmm36/charmm36-mar2019.ff


This file has been downloaded from https://github.com/YAMACS-SML/YAMACS under GPL-3.0 license.